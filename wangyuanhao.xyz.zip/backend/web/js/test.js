//alert("");
alert($(document).width());